Parsley.addMessages('it', {
  dateiso: "Inserire una data valida (AAAA-MM-GG)."
});
