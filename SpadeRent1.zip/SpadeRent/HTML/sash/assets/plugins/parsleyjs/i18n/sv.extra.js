Parsley.addMessages('sv', {
  dateiso: "Ange ett giltigt datum (ÅÅÅÅ-MM-DD)."
});
