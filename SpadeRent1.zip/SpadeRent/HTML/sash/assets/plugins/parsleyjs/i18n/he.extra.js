Parsley.addMessages('he', {
  dateiso: "ערך זה צריך להיות תאריך בפורמט (YYYY-MM-DD)."
});
