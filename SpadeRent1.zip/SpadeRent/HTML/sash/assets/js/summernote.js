(function (e) {
    'use strict';
    $('#summernote').summernote();
})();