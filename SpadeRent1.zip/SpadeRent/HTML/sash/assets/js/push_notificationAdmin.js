function notificationIconDisplay(){
    $(document).ready(function (){
    });
}
notificationIconDisplay()